<?php
/* 	DISCUSSION Theme's Footer
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 1.0
*/
?>




<br /><br /><br />
<div id="footer">
<div id="creditline">&copy;&nbsp;<?php echo date("Y") ?>&nbsp;<?php bloginfo( 'name' ); echo '&nbsp;| DISCUSSION Theme by: <a href="'.esc_url('https://d5creation.com').'" target="_blank"><img  src="' . get_template_directory_uri() . '/images/d5logofooter.png" /> D5 Creation</a> | Powered by: <a href="http://wordpress.org" target="_blank">WordPress</a>'; ?></div>
<?php wp_footer(); ?>
</div> <!-- footer -->
</div><!-- container -->
</body>
</html>