<?php 
/* 	DISCUSSION Theme's Slide Part
	Copyright: 2015-2016, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 1.5
*/
?>
<div class="slider-parent screw-back box100">
<div id="slider-box-item" class="mainslider box100 bcolor-back">
<div id="mslider" class="owl-carousel owl-theme">
 
  	<div class="item">
 		<div class="mslider-image"><img src="<?php header_image(); ?>"></div>
	</div>
</div>
</div>
</div>




