<?php 
/* 	DISCUSSION Theme's Post Slide Part
	Copyright: 2015-2016, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 2.1
*/
?>		
		<div class="clear"></div>
		<div id="thambslide" class="screw-back">
        <ul id="scroller">
		<?php 
  		$args = array( 'numberposts' => '20', 'post_type' => 'post' ); $thumbnails = get_posts($args);
		$discussion_counter = 0;
  		foreach ($thumbnails as $thumbnail) {   
    	if ( has_post_thumbnail($thumbnail->ID)) {   if ( $discussion_counter > 5 ): break; endif;
      	echo '<li><a href="' . get_permalink( $thumbnail->ID ) . '">';
      	echo get_the_post_thumbnail($thumbnail->ID, 'thumbnail');
      	echo '</a></li>'; 
		$discussion_counter++;
    	} }
		?>
        </ul>
        </div>
