<?php 
/* 	DISCUSSION Theme's About Page
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 3.0
*/
?>

<div id="about-page">

	<h1 class="about-title"><i>About</i> <span>DISCUSSION</span></h1>

	<div class="specialmsg">
    
    <h2>IMPORTANT NOTE !</h2>As per the Requirements of New Theme Review Guidelines, Theme Options will not be available at this location anymore for the Free Version of DISCUSSION Theme. You can get all those options under <b>Appearance > Customize</b><br /><br />
    
    If you love the Excellent Previous Style Options You may consider using our <a href="<?php echo esc_url('https://d5creation.com/themegallery/'); ?>" target="_blank">Extend Version Themes</a>. <span class="impspe">All Options will be under <b>Appearance > DISCUSSION Options</b> with large screen and user friendtly Interface in Extended Version</span>
    </div>
    
    <div class="infohead"><span class="donation">A Theme is an effort of many sleepless nights of the Developers.  If you like this FREEE Theme You can consider for a 5 star rating and honest review. Your review will inspire us. You can<a href="https://wordpress.org/support/view/theme-reviews/discussion" target="_blank"> <strong>Review Here</strong></a></span><br /><br /><br /><span class="donation"> Need More Features and Options ? Try <a href="https://d5creation.com/theme/discussion/" target="_blank"><strong>DISCUSSION Extend</strong></a></span><br /> <br /><br /><span class="donation"> You can Visit the DISCUSSION Extend <a href="http://demo.d5creation.com/themes/?theme=DISCUSSION" target="_blank"><strong>DEMO Here</strong></a></span><a href="https://d5creation.com/theme/discussion/" target="_blank" class="extendlink"> </a>
	</div>
        
        <p class="heading-des" >DISCUSSION is a theme for Bloggers. All the pages, posts and contents are designed on a notice board using push pin and sheets. You may like te stylish design. D5 Creation's Support will be with you, Always!</p>
        
        <div class="floatcntr">
    		<a class="specialbutton inblk" href="<?php echo esc_url('https://d5creation.com/theme/discussion/'); ?>">DISCUSSION Theme Page</a>
            <a class="specialbutton inblk" href="<?php echo esc_url('http://demo.d5creation.com/themes/?theme=DISCUSSION'); ?>">DISCUSSION Demo</a>
            <a class="specialbutton inblk" href="<?php echo esc_url('https://d5creation.com/themegallery/'); ?>">D5 Theme Gallery</a>
    	</div>
         
          
        <div class="specialmsg">
    		<div class="specialtext floatlt ">Learn More about our Flexible Membership Options</div>
        	<a class="specialbutton floatrt" href="<?php echo esc_url('https://d5creation.com/mp/'); ?>">View Pricing and Features</a>
    	</div>
         <div class="bottom"><img src="<?php echo get_template_directory_uri().'/inc/images/bottom.png'; ?>" alt="D5 Creation Themes"/></div>
         
         <div class="floatcntr">
		<h2 class="spetitle">World Class, Responsive and Premium WordPress Themes</h2>
		<p class="heading-des" >Ready to take your WordPress site to the next level? Give your CMS a beautiful design to draw in more visitors. Peoples love us because of the Simplicity of our Themes. We deliver User Friendly Responsive and Premium WordPress Themes with Unique and Modern Design. You can Trust our Themes</p>
		
		<a class="specialbutton inblk" target="_blank" href="<?php echo esc_url( 'https://d5creation.com/themegallery' ) ?>">Visit Our Theme Gallery</a>
        <a class="specialbutton inblk" target="_blank" href="<?php echo esc_url( 'http://demo.d5creation.com' ) ?>">Visit Theme Demos</a>
		<a class="specialbutton inblk" target="_blank" href="<?php echo esc_url( 'https://d5creation.com/wp-login.php?action=register' ) ?>">Become a Happy Member</a> <br /><br /><br />
        
        <img width="100%" src="<?php echo get_template_directory_uri() . '/inc/images/themefeatures.png' ?>" alt="D5 Creation Themes" />
	</div>   

</div>