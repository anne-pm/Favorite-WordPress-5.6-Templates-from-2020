<?php
/* 	DISCUSSION Theme's Functions
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 1.0
*/

	function discussion_about_page() { 
	add_theme_page( 'DISCUSSION Options', 'DISCUSSION Options', 'edit_theme_options', 'theme-about', 'discussion_theme_about' ); 
	}
	add_action('admin_menu', 'discussion_about_page');
	function discussion_theme_about() {  require_once ( trailingslashit(get_template_directory()) . 'inc/theme-about.php' ); }	
	function discussion_setup() {
	//	Set the content width based on the theme's design and stylesheet.
	global $content_width;
	if ( ! isset( $content_width ) ) $content_width = 584;
	
	add_theme_support( 'automatic-feed-links' );
  	register_nav_menus( array( 'main-menu' => __('Main Menu','discussion') ) );
	
	add_editor_style();
	add_theme_support( "title-tag" );
	load_theme_textdomain( 'discussion', get_template_directory() . '/languages' );
// 	This theme uses Featured Images (also known as post thumbnails) for per-post/per-page Custom Header images
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 300, 300, true ); // default Post Thumbnail dimensions (cropped)
		
// 	WordPress 3.4 Custom Background Support	
	$discussion_custom_background = array(
	'default-color'          => '966c40',
	'default-image'          => get_template_directory_uri() . '/images/back.jpg',
	);
	add_theme_support( 'custom-background', $discussion_custom_background );
	
// 	WordPress 3.4 Custom Header Support				
	$discussion_custom_header = array(
	'default-image'          => get_template_directory_uri() . '/images/slide.jpg',
	'random-default'         => false,
	'width'                  => 1000,
	'height'                 => 515,
	'flex-height'            => false,
	'flex-width'             => false,
	'default-text-color'     => '000000',
	'header-text'            => false,
	'uploads'                => true,
	'wp-head-callback' 		 => '',
	'admin-head-callback'    => '',
	'admin-preview-callback' => '',
	);
	add_theme_support( 'custom-header', $discussion_custom_header ); }
	add_action( 'after_setup_theme', 'discussion_setup' );

// 	Functions for adding script
	function discussion_enqueue_scripts() {
	wp_enqueue_style('discussion-style', get_stylesheet_uri());
	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) { 
		wp_enqueue_script( 'comment-reply' ); 
	}
	
	wp_enqueue_script( 'discussion-menu-style', get_template_directory_uri(). '/js/menu.js', array( 'jquery') );
	wp_register_style('discussion-gfonts1', '//fonts.googleapis.com/css?family=Oswald', false );
	wp_enqueue_style('discussion-gfonts1');
	
	// Load the html5 shiv.
	wp_enqueue_script( 'discussion-html5', get_template_directory_uri() . '/js/html5.js', array() );
	wp_script_add_data( 'discussion-html5', 'conditional', 'lt IE 9' );
	
	}
	add_action( 'wp_enqueue_scripts', 'discussion_enqueue_scripts' );
	
	function discussion_admin_style() { wp_enqueue_style( 'discussion_admin_css', get_template_directory_uri() . '/inc/admin-style.css', false ); }
	add_action( 'admin_enqueue_scripts', 'discussion_admin_style' );


//	function tied to the excerpt_more filter hook.
	function discussion_excerpt_length( $length ) {
	global $discussion_ExcerptLength;
	if ($discussion_ExcerptLength) {
    return $discussion_ExcerptLength;
	} else {
    return 50; //default value
    } }
	add_filter( 'excerpt_length', 'discussion_excerpt_length', 999 );
	
	function discussion_excerpt_more($more) {
       global $post;
	return '<a href="'. get_permalink($post->ID) . '" class="read-more">Read the Rest...</a>';
	}
	add_filter('excerpt_more', 'discussion_excerpt_more');


//	Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link
	function discussion_page_menu_args( $args ) {
	$args['show_home'] = true;
	return $args;
	}
	add_filter( 'wp_page_menu_args', 'discussion_page_menu_args' );


//	Registers the Widgets and Sidebars for the site
	function discussion_widgets_init() {

	register_sidebar( array(
		'name' =>  __('Primary Sidebar',  'discussion'), 
		'id' => 'sidebar-1',
		'before_widget' => '<aside id="%1$s" class="widget %2$s">',
		'after_widget' => "</aside>",
		'before_title' => '<h3 class="widget-title">',
		'after_title' => '</h3>',
	) );
	}
	add_action( 'widgets_init', 'discussion_widgets_init' );

	add_filter('the_title', 'discussion_title');
	function discussion_title($title) {
        if ( '' == $title ) {
            return '(Untitled)';
        } else {
            return $title;
        }
    }

//	Remove WordPress Custom Header Support for the theme discussion
//	remove_theme_support('custom-header');