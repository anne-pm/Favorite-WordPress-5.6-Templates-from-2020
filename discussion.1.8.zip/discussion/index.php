<?php 
/* 	DISCUSSION Theme's Index Page to hsow Blog Posts
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 1.0
*/

get_header(); ?>
<div id="content">
 <?php if (have_posts()) : while (have_posts()) : the_post();?>
<div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
 <p class="postmetadataw">Posted by: <?php the_author_posts_link() ?> | on <?php the_time('F j, Y'); ?></p>		
 <div class="content-ver-sep"> </div>
 <h2 class="post-title"><a href="<?php the_permalink(); ?>"><?php the_title();?></a></h2>
 <div class="content-ver-sep"> </div>
 <div class="entrytext"><?php the_post_thumbnail('thumbnail'); ?>
  <?php the_content('<p class="read-more">'.__('Read the rest of this page','discussion').'  &raquo;</p>'); ?>
 <div class="clear"> </div>
 <div class="up-bottom-border">
 <p class="postmetadata">Posted in <?php the_category(', ') ?> | <?php edit_post_link('Edit', '', ' | '); ?>  <?php comments_popup_link('No Comments &#187;', '1 Comment &#187;', '% Comments &#187;'); ?> <?php the_tags('<br />Tags: ', ', ', '<br />'); ?></p>
 </div>
 </div></div>
 
 <?php endwhile; ?>

<div id="page-nav">
	<div class="alignleft"><?php previous_posts_link('&laquo; '. __('Newer Entries', 'discussion')) ?></div>
	<div class="alignright"><?php next_posts_link( __('Older Entries','discussion').'  &raquo;','') ?></div>
</div>
  
 
 <?php else: ?>
 
 <h1 class="arc-post-title"><?php echo __('Not Found Anything', 'discussion') ?></h1>
		
		<h3 class="arc-src"><span><?php echo __('Apologies, but the page you requested could not be found. Perhaps searching will help.', 'discussion') ?></span></h3>
		<?php get_search_form(); ?>
		<p><a href="<?php echo home_url(); ?>" title="Browse the Home Page">&laquo; <?php echo __('Or Return to the Home Page', 'discussion') ?></a></p><br />
		 
<?php endif; ?>
 

</div>

<?php get_sidebar(); ?>
<?php get_footer(); ?>