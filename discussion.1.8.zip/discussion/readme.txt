=== DISCUSSION ===

Contributors: D5 Creation
Tags: two-columns, right-sidebar, custom-header, blog, custom-background, e-commerce, custom-menu,  entertainment, threaded-comments, sticky-post, full-width-template, translation-ready, rtl-language-support
Requires at least: 4.0
Tested up to: 5.2.2-RC1-45523
Stable tag: 1.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

DISCUSSION Blog and Portfolio Theme

== Description ==

DISCUSSION is a theme for Bloggers. All the pages, posts and contents are designed on a notice board using push pin and sheets. You may like te stylish design. D5 Creation's Support will be with you, Always.

== Frequently Asked Questions ==

= What to do after Theme Installation ? =
You can set the Header Image from Appearance > Header. You can change the Background from Appearance > Background. The 06 Thumb Image will come from the last 06 posts' featured images. The Menu should be within the Screen Width.

= Why is DISCUSSION? =
DISCUSSION is for Personal and Corporate Blog and Portfolio Sites

= Can it be used for Personal or Company Websites? =
You can use for Personal to Corporate Sites

= Is it only for Blogs ? =
No, It is for Blogs, Company, Personal Websites etc.


== Changelog ==

= 1.8 =
* New Readme File Added
* Images Change
* Bug Fix

= 1.5 =
* Right Sidebar Serch WidGet Dynamic
* Some Styling Change

= 1.5 =
* Code Cleanup
* Some Styling Change

== Resources ==
* html5.js: https://github.com/aFarkas/html5shiv, MIT/GPL2

* slide.jpg: https://stocksnap.io/photo/UEQ0178WUT
* screenshot.png: https://stocksnap.io/photo/RPNR8Z1UW0, https://stocksnap.io/photo/HB3OM9NP8M, https://stocksnap.io/photo/E1WZHWID6J, https://stocksnap.io/photo/GE7GGDMILW, https://stocksnap.io/photo/543AN96EAW, https://stocksnap.io/photo/OB8I3EWMW7