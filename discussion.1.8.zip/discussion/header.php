<?php

/* 	DISCUSSION Theme's Header
	Copyright: 2012-2017, D5 Creation, www.d5creation.com
	Based on the Simplest D5 Framework for WordPress
	Since DISCUSSION 1.0
*/
?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width" />
<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!--[if lt IE 9]>
<script src="<?php echo get_template_directory_uri(); ?>/js/html5.js" type="text/javascript"></script>
<![endif]-->

<?php 

wp_head(); ?>

</head>

<body <?php body_class(); ?> >

  <div id="container">
  	        
	  <div id ="header">
      <!-- Site Main Menu Goes Here -->
        <nav id="main-menu-con" >
		<?php if ( has_nav_menu( 'main-menu' ) ) :  wp_nav_menu( array( 'theme_location' => 'main-menu', 'menu_class' => 'mainmenu', 'container_class' => 'mainmenu-parent' )); else: wp_page_menu(); endif; ?>
        </nav>
        <div class="clear"></div>
     
      <div id ="header-content">
      	<!-- Site Titele and Description Goes Here -->
      	 <h2 class="site-des"><?php bloginfo( 'description' ); ?></h2>
        <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><h1 class="site-title"><?php echo bloginfo( 'name' ); ?></h1></a>
    
		</div><!-- header-content -->
        
        <?php get_template_part( 'fpcontents/fp', 'slide' ); get_template_part( 'fpcontents/fp', 'pslide' ); ?>
          
        
        </div><!-- header -->