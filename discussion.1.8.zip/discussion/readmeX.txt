----------------------------------
DISCUSSION
----------------------------------
Version: 	1.7
Developer: 	D5 Creation
Author URI: 	https://d5creation.com

Donation Link: 	https://d5creation.com/donate/

Copyright: 	D5 Creation
License: 		GNU General Public License v2 or later
License URI: 	http://www.gnu.org/licenses/gpl-2.0.html

This Product is provided "as is" with no warranty or liabilities of D5 Creation. 

License:
back.jpg
CC0 Public Domain by binhob  - https://pixabay.com/en/paper-texture-brown-background-1222380

screenshot.png and slide.jpg
CC0 Public Domain by luxstorm  - https://pixabay.com/en/young-woman-female-smiling-858730

CC0 Public Domain by PublicDomainPictures  - https://pixabay.com/en/users/PublicDomainPictures-14

CC0 Public Domain by PublicDomainPictures  - https://pixabay.com/en/christmas-claus-cute-gift-girl-15651

CC0 Public Domain by PublicDomainPictures  - https://pixabay.com/en/apple-cute-diet-female-food-fruit-16672

CC0 Public Domain by AdinaVoicu  - https://pixabay.com/en/girl-about-red-blue-eyes-tulips-1308317

CC0 Public Domain by AdinaVoicu  - https://pixabay.com/en/girl-red-green-eyes-beauty-1308307

CC0 Public Domain by AdinaVoicu  - https://pixabay.com/en/girl-orange-wood-timber-blue-eyes-1324561


All the PHP Code, Images and other particulars included with this product are licensed under the same License: GNU General Public License v2 or later .



Changelog:
-------------------------

Version 1.5
_____________________
- Right Sidebar Serch WidGet Dynamic
- Some Styling Change

Version 1.5
_____________________
- Code updated as per the Guideline
- Some Styling Change

Instruction:
-----------------
- You can set the Header Image from Appearance > Header
- You can change the Background from Appearance > Background
- The 06 Thumb Image will come from the last 06 posts' featured images
- The Menu should be within the Screen Width