
CONTRIBUTING YOUR TRANSLATION


This theme is ready for translation and has already been translated into several languages. But If your language is not available then you can make one. It is also possible that not all existing translations are up-to-date or correct, so you are welcome to make corrections. Many of theme users would be delighted if you share your translation with the community. Thanks for your contribution!

  * English (default)
  * Russian (translated by Arthur Gareginyan)
  * Ukrainian (translated by Svetlana Drotyanko)
  * Slovak (translated by Martin Petrus)
  * Afrikaans (translated by MadriVictor)
  * Spanish (translated by Ivan Ratinoff)
  * Polish (translated by Krzysztof Goral)
  * German (translated by Alexander v. Falkenhausen)
  * Estonian (translated by Taavi Tiitsmaa)
  * Catalan (translated by Nestor Malet)
  * Danish (translated by Chano Klinck Andersen)
  * French (translated by Rolland Dudemaine)

If you want to help translate this theme, please visit the [translation page](https://translate.wordpress.org/projects/wp-themes/anarcho-notepad). You can also use the POT file that is included and placed in the "languages" folder to create a translation PO file. Just send the PO file to us (https://www.spacexchimp.com/contact.html) and we will include this translation within the next plugin update.
