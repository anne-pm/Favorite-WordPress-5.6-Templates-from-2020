/*
 * Theme JavaScript and JQuery code for the frontend pages of website
 *
 * Copyright (c) 2020, Space X-Chimp ( https://www.spacexchimp.com ).
 * All Rights Reserved.
 */

jQuery(document).ready(function($) {



});