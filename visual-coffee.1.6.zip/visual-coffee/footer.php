</section> <!-- .grid -->
</main>
</div> <!-- #page -->

<footer id="site-footer" itemscope itemtype="http://schema.org/WPFooter">
	&copy;<?php echo date( 'Y' ); ?> <?php bloginfo( 'name' ); ?> &middot; <?php _e( 'Theme by', 'visual-coffee' ); ?> <a rel="nofollow" href="https://visual.coffee">Visual.Coffee</a>
</footer>
<?php wp_footer(); ?>

</body>
</html>